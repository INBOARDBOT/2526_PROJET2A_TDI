################################################################################
# Automatically-generated file. Do not edit!
# Toolchain: GNU Tools for STM32 (14.3.rel1)
################################################################################

# Add inputs and outputs from these tool invocations to the build variables 
C_SRCS += \
../Core/lib/corrector/corrector.c 

OBJS += \
./Core/lib/corrector/corrector.o 

C_DEPS += \
./Core/lib/corrector/corrector.d 


# Each subdirectory must supply rules for building sources it contributes
Core/lib/corrector/%.o Core/lib/corrector/%.su Core/lib/corrector/%.cyclo: ../Core/lib/corrector/%.c Core/lib/corrector/subdir.mk
	arm-none-eabi-gcc "$<" -mcpu=cortex-m4 -std=gnu11 -g3 -DDEBUG -DUSE_HAL_DRIVER -DSTM32G431xx -c -I../Core/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc -I../Drivers/STM32G4xx_HAL_Driver/Inc/Legacy -I../Drivers/CMSIS/Device/ST/STM32G4xx/Include -I../Drivers/CMSIS/Include -I../Middlewares/ST/ARM/DSP/Inc -I../Core/lib -O0 -ffunction-sections -fdata-sections -Wall -fstack-usage -fcyclomatic-complexity -MMD -MP -MF"$(@:%.o=%.d)" -MT"$@" --specs=nano.specs -mfpu=fpv4-sp-d16 -mfloat-abi=hard -mthumb -o "$@"

clean: clean-Core-2f-lib-2f-corrector

clean-Core-2f-lib-2f-corrector:
	-$(RM) ./Core/lib/corrector/corrector.cyclo ./Core/lib/corrector/corrector.d ./Core/lib/corrector/corrector.o ./Core/lib/corrector/corrector.su

.PHONY: clean-Core-2f-lib-2f-corrector

