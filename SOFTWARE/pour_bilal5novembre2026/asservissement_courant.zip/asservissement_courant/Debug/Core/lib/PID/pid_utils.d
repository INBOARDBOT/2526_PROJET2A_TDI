Core/lib/PID/pid_utils.o: ../Core/lib/PID/pid_utils.c \
 ../Core/lib/PID/pid_utils.h ../Core/lib/PID/pid_config.h \
 ../Core/lib/FOC/foc_math.h ../Middlewares/ST/ARM/DSP/Inc/arm_math.h \
 ../Drivers/CMSIS/Include/cmsis_compiler.h \
 ../Drivers/CMSIS/Include/cmsis_gcc.h
../Core/lib/PID/pid_utils.h:
../Core/lib/PID/pid_config.h:
../Core/lib/FOC/foc_math.h:
../Middlewares/ST/ARM/DSP/Inc/arm_math.h:
../Drivers/CMSIS/Include/cmsis_compiler.h:
../Drivers/CMSIS/Include/cmsis_gcc.h:
