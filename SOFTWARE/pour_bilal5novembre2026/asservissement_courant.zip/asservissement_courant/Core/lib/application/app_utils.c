#include <application/app_utils.h>
#include "main.h"



void application_init(FSM_HandleTypeDef *application, FOC_HandleTypeDef *foc_control_system,
		COM_HandleTypeDef *communication_system){
	if(application == NULL)return;

	application->foc_control   = foc_control_system;
	application->communication = communication_system;
}

void application_setup(FSM_HandleTypeDef *application){
	FOC_HandleTypeDef *foc_control = application->foc_control;

	init_foc_control(foc_control);
}


void exec_loop_20kHz(FSM_HandleTypeDef *application){
	FOC_HandleTypeDef *foc_control    = application->foc_control;
	ENC_HandleTypeDef *encoder        = foc_control->encoder;
	TIM_HandleTypeDef *encoder_timer  = foc_control->timer_encoder;
	MOT_HandleTypeDef *motor_control  = foc_control->motor;

	update_encoder(encoder, encoder_timer, motor_control->pole_pairs);
	update_current_feedback(foc_control);

	current_corrector_sequence(foc_control);


	control_motor(foc_control, encoder->elec_angle);
}

void exec_loop_500Hz(FSM_HandleTypeDef *application){
	FOC_HandleTypeDef *foc_control   = application->foc_control;

	speed_corrector_sequence(foc_control);
}

void exec_loop_50Hz(FSM_HandleTypeDef *application){
//	position_corrector_sequence();
}
