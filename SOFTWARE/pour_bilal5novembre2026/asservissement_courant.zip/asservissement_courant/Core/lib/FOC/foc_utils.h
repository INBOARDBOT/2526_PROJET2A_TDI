#ifndef FOC_UTILS_H
#define FOC_UTILS_H


#define CAL_SETTLE_TICKS   512u
#define CAL_ITERATIONS     500u
#define CAL_UQ             2.0f
#define CAL_UD             0.0f


#include <corrector/corrector.h>
#include <peripherals/encoder/encoder_utils.h>
#include <peripherals/motor/motor_utils.h>
#include <peripherals/ADC/analog_utils.h>
#include <PID/pid_utils.h>

/******************************************[ FOC/SINGAL INIT ]******************************************/


void foc_init(FOC_HandleTypeDef *foc_control, TIM_HandleTypeDef *htim1,
		TIM_HandleTypeDef *htim2, TIM_HandleTypeDef *htim3,
		TIM_HandleTypeDef *htim4, ADC_HandleTypeDef *hadc1, ADC_HandleTypeDef *hadc2);


/******************************************[ FOC control loop ]******************************************/

void init_foc_control(FOC_HandleTypeDef *fonc_control);
void foc_speed_control_update(FOC_HandleTypeDef *fonc_control);
void foc_current_control_update(FOC_HandleTypeDef *fonc_control);

/*******************************************[ FOC additional ]*******************************************/

void foc_position_control_update(FOC_HandleTypeDef *fonc_control);

/******************************************[ OPEN LOOP CONTROL ]*****************************************/

void open_loop_velocity_run(FOC_HandleTypeDef *fonc_control, float32_t target_rpm);
void open_loop_velocity_run_SVPWM(FOC_HandleTypeDef *fonc_control, float32_t target_rpm);

/******************************************[ CALIBRATION ]*****************************************/

void control_motor(FOC_HandleTypeDef *foc_control, float32_t angle);
void mag_misalignement(FOC_HandleTypeDef *foc_system);
void mag_misalignement_encoder(FOC_HandleTypeDef *foc_system);

void zero_settings_calibration(FOC_HandleTypeDef *foc_system);
void go_to_position(FOC_HandleTypeDef *foc_system, float32_t target_pos_deg, float32_t speed_rpm);

#endif
