#include "foc_utils.h"

typedef enum {
	MAG_INIT,
	MAG_LOCK,
	MAG_APPLY,
	MAG_DONE
} mag_state;

typedef enum {
    ZERO_IDLE,
	ZERO_LOCK_ZERO,
	ZERO_SEEK_Z_PULSE,
	ZERO_APPLY_OFFSET,
	ZERO_DONE
} zero_state;

/******************************************[ FOC inits ]******************************************/


void foc_init(FOC_HandleTypeDef *foc_control, TIM_HandleTypeDef *htim1,
		TIM_HandleTypeDef *htim2, TIM_HandleTypeDef *htim3,
		TIM_HandleTypeDef *htim4, ADC_HandleTypeDef *hadc1, ADC_HandleTypeDef *hadc2){

	if(foc_control == NULL)return;

	foc_control->adc1   = hadc1;
	foc_control->adc2   = hadc2;
	foc_control->timer_20kHz = htim1;
	foc_control->timer_500Hz = htim2;
	foc_control->timer_50Hz = htim4;
	foc_control->timer_encoder = htim3;
}



/********************************************************************************************************/


/*******************************************[ FOC additional ]*******************************************/


/********************************************************************************************************/

/******************************************[ OPEN LOOP CONTROL ]*****************************************/

void open_loop_velocity_run(FOC_HandleTypeDef *fonc_control, float32_t target_rpm)
{
    MOT_HandleTypeDef  *motor        = fonc_control->motor;
    TIM_HandleTypeDef  *htim_pwm     = fonc_control->timer_20kHz;
    float32_t           Ts           = 0.001f;

    static float32_t position_setpoint = 0.0f;

    float32_t elec_rpm    = target_rpm * (float32_t)motor->pole_pairs;
    float32_t deg_per_sec = (elec_rpm / 60.0f) * 360.0f;
    float32_t delta_theta = deg_per_sec * Ts;

    position_setpoint += delta_theta;

    if (position_setpoint >= 360.0f) position_setpoint -= 360.0f;
    if (position_setpoint < 0.0f)    position_setpoint += 360.0f;

    float32_t v_norm = 0.2f; // foc_signal->V_open_loop;

    float32_t sin_a, sin_b, sin_c, unused;
    arm_sin_cos_f32(position_setpoint,          &sin_a, &unused);
    arm_sin_cos_f32(position_setpoint - 120.0f, &sin_b, &unused);
    arm_sin_cos_f32(position_setpoint + 120.0f, &sin_c, &unused);

    uint32_t pwm_a = (uint32_t)(((sin_a * v_norm) * 0.5f + 0.5f) * 8000);
    uint32_t pwm_b = (uint32_t)(((sin_b * v_norm) * 0.5f + 0.5f) * 8000);
    uint32_t pwm_c = (uint32_t)(((sin_c * v_norm) * 0.5f + 0.5f) * 8000);

    motor_set_pwm(motor, htim_pwm, pwm_a, pwm_b, pwm_c);
}

void open_loop_velocity_run_SVPWM(FOC_HandleTypeDef *fonc_control, float32_t target_rpm)
{
    MOT_HandleTypeDef  *motor        = fonc_control->motor;
    TIM_HandleTypeDef  *htim_pwm     = fonc_control->timer_20kHz;
    float32_t           Ts           = TS_OPEN_LOOP;
    float32_t           Vbus         = 19.0f;

    static float32_t theta_electrique = 0.0f;
    float32_t Ualpha, Ubeta;

    float32_t omega = target_rpm * RPM_TO_RAD_S * (float32_t)motor->pole_pairs;

    theta_electrique += omega * Ts; // Change this
//    position_setpoint = theta_electrique * 57.2957795131f;

    if (theta_electrique >= TWO_PI)theta_electrique -= TWO_PI;
    else if (theta_electrique < 0.0f)theta_electrique += TWO_PI;
    park_invtransforn(motor->Ud, motor->Uq, theta_electrique,
    		&Ualpha, &Ubeta);

    uint32_t pwm_u, pwm_v, pwm_w;
	svpwm(Ualpha, Ubeta, Vbus,
			motor->pwm_resolution, &pwm_u, &pwm_v, &pwm_w);

	motor_set_pwm(motor, htim_pwm, pwm_u, pwm_v, pwm_w);
}


void init_foc_control(FOC_HandleTypeDef *foc_control){
	/* PID CONF AND VALUE */
	init_corrector(foc_control->pid_control);

	/* ENCODER */
	encoder_init(foc_control->encoder);

	/* ANALOG */
	analog_init(foc_control->analog, foc_control->adc1, foc_control->adc2);

	/* MOTOR */
	motor_init(foc_control->motor, foc_control->timer_20kHz);

	/* TIMER */
	start_encoder_timer(foc_control);
	start_injection_channel(foc_control);
	__HAL_TIM_ENABLE_IT(foc_control->timer_20kHz, TIM_IT_BREAK);
	motor_start(foc_control->motor, foc_control->timer_20kHz);

	/* POSITION and SPEED */
	start_speed_timer(foc_control);
	start_position_timer(foc_control);

	/* GENERAL TIMER */
	start_general_timer(foc_control);
}

/******************************************[ CALIBRATION ]*****************************************/

void control_motor(FOC_HandleTypeDef *foc_control, float32_t angle)
{
	MOT_HandleTypeDef *motor_Control   = foc_control->motor;

	float32_t Ud    = motor_Control->Ud;
	float32_t Uq    = motor_Control->Uq;

	float32_t Ualpha, Ubeta;
    park_invtransforn(Ud, Uq, angle, &Ualpha, &Ubeta);

    uint32_t pu, pv, pw;
    svpwm(Ualpha, Ubeta, 24.0f, foc_control->motor->pwm_resolution, &pu, &pv, &pw);
    motor_set_pwm(foc_control->motor, foc_control->timer_20kHz, pu, pv, pw);
}


void mag_misalignement_encoder(FOC_HandleTypeDef *foc_system)
{
    ENC_HandleTypeDef  *enc   = foc_system->encoder;
    MOT_HandleTypeDef  *motor = foc_system->motor;
    MOT_HandleTypeDef  *motor_control   = foc_system->motor;
    TIM_HandleTypeDef  *htim  = foc_system->timer_encoder;

    static mag_state   cal_state    = MAG_INIT;
    static uint32_t    tick         = 0;
    static float32_t   offset_accum = 0.0f;

    motor_control->Ud = 0.0f;
    motor_control->Uq = 4.0f;

	switch (cal_state)
	{

		case MAG_INIT:
			encoder_reset(enc);
			cal_state = MAG_LOCK;
			break;

		case MAG_LOCK:
			control_motor(foc_system, 0.0f);
			update_encoder(enc, htim, motor->pole_pairs);

			offset_accum += get_encoder_position(enc);

			if (++tick >= CAL_SETTLE_TICKS) {
				tick         = 0;
				offset_accum /= (float32_t)CAL_SETTLE_TICKS;

				encoder_set_magnetic_offset(enc, (int)offset_accum);
				cal_state    = MAG_APPLY;
			}
			break;
		 case MAG_APPLY:

			if (++tick >= CAL_SETTLE_TICKS) {
				tick         = 0;
				motor->motor_flags |= FLAG_ZABLE;
				cal_state = MAG_DONE;
			}
			break;

		case MAG_DONE:
			break;
	}
}

