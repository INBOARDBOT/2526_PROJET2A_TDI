#ifndef FOC_CONFIG_H
#define FOC_CONFIG_H

#include "stm32g4xx_hal.h"
#include <corrector/corrector_config.h>
#include <peripherals/encoder/encoder_config.h>
#include <peripherals/motor/motor_config.h>
#include <peripherals/ADC/analog_config.h>
#include <PID/pid_config.h>

#define MAX_BUFFER   256

#define TS_500Hz     0.002f
#define FREQ_500Hz   500.0f

#define TS_10kHz     0.0001f
#define FREQ_10kHz   10000.0f

#define TS_50Hz      0.002f
#define FREQ_50Hz    50.0f

#define TS_OPEN_LOOP 0.0001f

#define CLOCK_FREQ            170000000.0f
#define CLOCK_FREQ_INVS       (float32_t)(1.0f / CLOCK_FREQ)
#define SPEED_TIMEOUT_TICKS   (uint32_t)(CLOCK_FREQ * 0.05f)


#define ENABLE_CYCLE_COUNTER() do { \
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk; \
    DWT->CYCCNT = 0; \
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk; \
} while(0)


typedef struct {

	TIM_HandleTypeDef     *timer_encoder;
	TIM_HandleTypeDef     *timer_20kHz;
	TIM_HandleTypeDef     *timer_500Hz;
	TIM_HandleTypeDef     *timer_50Hz;

	ADC_HandleTypeDef     *adc1;
	ADC_HandleTypeDef     *adc2;

	ENC_HandleTypeDef     *encoder;

	MOT_HandleTypeDef     *motor;

	ANG_HandleTypeDef     *analog;

	PID_HandleTypeDef     *pid_control;

	/* ISR sensitives not used as is */
	FOC_PositionControl_t *position_control;
	FOC_CurrentControl_t  *current_control;
	FOC_SpeedControl_t    *speed_control;

}FOC_HandleTypeDef;




void start_general_timer(FOC_HandleTypeDef *foc_control);
void stop_general_timer(FOC_HandleTypeDef *foc_control);

void start_injection_channel(FOC_HandleTypeDef *foc_control);
void stop_injection_channel(FOC_HandleTypeDef *foc_control);

void start_encoder_timer(FOC_HandleTypeDef *foc_control);
void stop_encoder_timer(FOC_HandleTypeDef *foc_control);


void start_speed_timer(FOC_HandleTypeDef *foc_control);
void stop_speed_timer(FOC_HandleTypeDef *foc_control);
void start_position_timer(FOC_HandleTypeDef *foc_control);
void stop_position_timer(FOC_HandleTypeDef *foc_control);

#endif
