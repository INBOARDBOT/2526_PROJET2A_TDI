#include <peripherals/encoder/encoder_utils.h>


void encoder_init(ENC_HandleTypeDef *encoder) {
    if (encoder == NULL) return;

    *encoder = (ENC_HandleTypeDef){ 0 };
    ENABLE_CYCLE_COUNTER();
}

void encoder_reset(ENC_HandleTypeDef *encoder){
	encoder->meca_angle         = 0.0f;
	encoder->elec_angle         = 0.0f;
	encoder->speed_rads         = 0.0f;
	encoder->loop_number        = 0.0f;
	encoder->now_timestamp      = 0U;
	encoder->absolute_position  = 0U;
	encoder->encoder_flag       = 0U;
	encoder->last_timestamp     = 0U;
	encoder->magnetic_offset    = 0U;
	encoder->position_raw       = 0U;
	encoder->position_raw_prev  = 0U;
	encoder->position_delta_raw = 0;
}

void encoder_set_magnetic_offset(ENC_HandleTypeDef *encoder, uint16_t offset) {
    encoder->magnetic_offset = offset;
    encoder->encoder_flag |= ENCODER_FLAG_MAGOFFS;
}

void update_encoder(ENC_HandleTypeDef *encoder, TIM_HandleTypeDef *timer_encoder, uint8_t pole_pairs){
	update_position(encoder, timer_encoder);
	update_speed(encoder);
	update_abs_position(encoder);
	update_angles(encoder, pole_pairs);
}

void update_position(ENC_HandleTypeDef *encoder, TIM_HandleTypeDef *timer_encoder){
	encoder->now_timestamp      = DWT->CYCCNT;
	encoder->position_raw_prev  = encoder->position_raw;
	encoder->position_raw       = timer_encoder->Instance->CNT;
	int32_t delta = (int32_t)encoder->position_raw - (int32_t)encoder->position_raw_prev;

	if (delta > (int32_t)ENCODER_PPEDGES_HALF)  delta -= (int32_t)ENCODER_PPEDGES;
	if (delta < -(int32_t)ENCODER_PPEDGES_HALF) delta += (int32_t)ENCODER_PPEDGES;

	encoder->position_delta_raw = (int16_t)delta;
}

void update_abs_position(ENC_HandleTypeDef *encoder) {
    encoder->absolute_position += encoder->position_delta_raw;
    encoder->loop_number = (float32_t)encoder->absolute_position * ENCODER_PPEDGES_INVS;
}

void update_speed(ENC_HandleTypeDef *encoder) {
    uint32_t now = encoder->now_timestamp;

    if (encoder->position_delta_raw != 0) {
        uint32_t delta_t_ticks = now - encoder->last_timestamp;

		float32_t dt           = (float32_t)delta_t_ticks * CLOCK_FREQ_INVS;
		float32_t distance_rad = (float32_t)encoder->position_delta_raw
								 * ENCODER_PPEDGES_INVS * TWO_PI;
		encoder->speed_rads = distance_rad / dt;

        encoder->last_timestamp = now;

    } else {
        if ((now - encoder->last_timestamp) > SPEED_TIMEOUT_TICKS) {
            encoder->speed_rads = 0.0f;
        }
    }
}


void update_angles(ENC_HandleTypeDef *encoder, uint8_t pole_pairs)
{
    encoder->meca_angle = (float32_t)encoder->position_raw * ENCODER_PPEDGES_INVS * TWO_PI;

    if (encoder->encoder_flag & ENCODER_FLAG_MAGOFFS) {
        int32_t raw_offset_corrected = (int32_t)encoder->position_raw - (int32_t)encoder->magnetic_offset;
        encoder->elec_angle = ((float32_t)raw_offset_corrected * ENCODER_PPEDGES_INVS * TWO_PI) * (float32_t)pole_pairs;
    } else {
        encoder->elec_angle = (encoder->meca_angle * (float32_t)pole_pairs);
    }

    while (encoder->elec_angle >= TWO_PI) encoder->elec_angle -= TWO_PI;
    while (encoder->elec_angle < 0.0f)     encoder->elec_angle += TWO_PI;
}

void update_encoder_interrupt(ENC_HandleTypeDef *encoder){
	encoder->encoder_flag |= ENCODER_FLAG_ZITR;
}

uint16_t get_encoder_position(ENC_HandleTypeDef *encoder){
	return encoder->position_raw;
}

float32_t get_encoder_speed(ENC_HandleTypeDef *encoder){
	return encoder->speed_rads;
}

uint64_t get_encoder_abbs_position(ENC_HandleTypeDef *encoder){
	return encoder->absolute_position;
}

float32_t get_encoder_meca_angle(ENC_HandleTypeDef *encoder){
	return encoder->meca_angle;
}

float32_t get_encoder_elec_angle(ENC_HandleTypeDef *encoder){
	return encoder->elec_angle;
}



