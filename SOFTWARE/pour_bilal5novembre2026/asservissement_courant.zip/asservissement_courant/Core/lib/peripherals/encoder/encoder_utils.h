#ifndef ENCODER_UTILS_H
#define ENCODER_UTILS_H

#include <FOC/foc_config.h>


void encoder_init(ENC_HandleTypeDef *encoder);
void encoder_reset(ENC_HandleTypeDef *encoder);


/* UPDATE FUNCTION */
void update_encoder(ENC_HandleTypeDef *encoder, TIM_HandleTypeDef *timer_encoder, uint8_t pole_pairs);
void update_position(ENC_HandleTypeDef *encoder, TIM_HandleTypeDef *timer_encoder);
void update_abs_position(ENC_HandleTypeDef *encoder);
void update_speed(ENC_HandleTypeDef *encoder);
void update_angles(ENC_HandleTypeDef *encoder, uint8_t pole_pairs);
void update_encoder_interrupt(ENC_HandleTypeDef *encoder);


/* SETTER FUNCTION */
void encoder_set_magnetic_offset(ENC_HandleTypeDef *encoder, uint16_t offset);

/* GETTER FUNCTION*/
uint16_t get_encoder_position(ENC_HandleTypeDef *encoder);
float32_t get_encoder_speed(ENC_HandleTypeDef *encoder);
uint64_t get_encoder_abbs_position(ENC_HandleTypeDef *encoder);
float32_t get_encoder_meca_angle(ENC_HandleTypeDef *encoder);
float32_t get_encoder_elec_angle(ENC_HandleTypeDef *encoder);

#endif
