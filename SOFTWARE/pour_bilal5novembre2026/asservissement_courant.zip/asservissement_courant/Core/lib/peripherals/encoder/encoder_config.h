#ifndef ENCODER_CONFIG_H
#define ENCODER_CONFIG_H

#include "arm_math.h"
#include <stdint.h>
#include <stdbool.h>

#define ENCODER_PPEDGES       4096U
#define ENCODER_PPEDGES_FLOAT 4096.0f
#define ENCODER_PPEDGES_HALF  2048U
#define ENCODER_PPEDGES_INVS  (float32_t)(1.0f / ENCODER_PPEDGES_FLOAT)

#define ENCODER_FLAG_ZITR    (1U << 0)
#define ENCODER_FLAG_MAGOFFS (1U << 1)
#define ENCODER_FLAG_2    (1U << 2)
#define ENCODER_FLAG_3    (1U << 3)
#define ENCODER_FLAG_4    (1U << 4)
#define ENCODER_FLAG_5    (1U << 5)
#define ENCODER_FLAG_6    (1U << 6)
#define ENCODER_FLAG_7    (1U << 7)



typedef struct {
	uint8_t       encoder_flag;

	float32_t     speed_rads;
	uint32_t      last_timestamp;
	uint32_t      now_timestamp;

	uint16_t      position_raw;
	uint16_t      position_raw_prev;
	int16_t       position_delta_raw;
	uint64_t      absolute_position;

	float32_t     loop_number;

	float32_t     elec_angle;
	float32_t     meca_angle;

	uint16_t      magnetic_offset;
}ENC_HandleTypeDef;





#endif
