#include <peripherals/ADC/analog_utils.h>


void analog_init(
		ANG_HandleTypeDef *current_sensor,
		ADC_HandleTypeDef *adc1,
		ADC_HandleTypeDef *adc2){

	HAL_ADCEx_Calibration_Start(adc1, ADC_SINGLE_ENDED);
	HAL_ADCEx_Calibration_Start(adc2, ADC_SINGLE_ENDED);

	HAL_ADCEx_InjectedStart_IT(adc1);
	HAL_ADCEx_InjectedStart_IT(adc2);
}


void update_current_sensor(
		ANG_HandleTypeDef *current_sensor,
		const ADC_HandleTypeDef *adc1,
		const ADC_HandleTypeDef *adc2
		){

	uint32_t raw_a_value = adc1->Instance->JDR1;
	uint32_t raw_c_value = adc2->Instance->JDR2;
	uint32_t raw_b_value = adc2->Instance->JDR1;

	float32_t amp_a_value = (float32_t)raw_a_value * VREF / (ADC_RESOLUTION * TOTAL_GAIN); // (vout_a - VMID) / (TOTAL_GAIN * SHUNT_RESISTOR);
	float32_t amp_c_value = (float32_t)raw_c_value * VREF / (ADC_RESOLUTION * TOTAL_GAIN); // (vout_c - VMID) / (TOTAL_GAIN * SHUNT_RESISTOR);
	float32_t amp_b_value = (float32_t)raw_b_value * VREF / (ADC_RESOLUTION * TOTAL_GAIN); // (vout_c - VMID) / (TOTAL_GAIN * SHUNT_RESISTOR);

	current_sensor->Ia = amp_a_value;
	current_sensor->Ic = amp_c_value;

	current_sensor->Ib = amp_b_value;
}

void update_vbus_voltage(ANG_HandleTypeDef *current_sensor, ADC_HandleTypeDef *adc1)
{
	uint32_t raw_vbus = adc1->Instance->JDR2;
	current_sensor->vbus = (float32_t)raw_vbus * CONVERSION_VBUS;  // HAL_ADCEx_InjectedGetValue(adc1, ADC_INJECTED_RANK_2) * CONVERSION_VBUS;

}


void update_current_feedback(FOC_HandleTypeDef *foc_control){
	ANG_HandleTypeDef *current_sensor  = foc_control->analog;
	ADC_HandleTypeDef *adc1_control    = foc_control->adc1;
	ADC_HandleTypeDef *adc2_control    = foc_control->adc2;
	ENC_HandleTypeDef *encoder_control = foc_control->encoder;

	static int ticks = 0;
	static float32_t Iq_measurement;
	static float32_t Id_measurement;

	update_current_sensor(current_sensor, adc1_control, adc2_control);

	float32_t Ia_current = current_sensor->Ia;
	float32_t Ib_current = current_sensor->Ib;
	float32_t theta_elec = encoder_control->elec_angle;

	float32_t Ialpha_current, Ibeta_current;
	float32_t Id_current, Iq_current;

	clark_transforn(Ia_current, Ib_current, &Ialpha_current, &Ibeta_current);
	park_transforn(Ialpha_current, Ibeta_current, theta_elec, &Id_current, &Iq_current);

	Id_measurement += Id_current;
	Iq_measurement += Iq_current;

	if(++ticks > (SAMPLES_AVG - 1)){
		current_sensor->Id_feedback = Id_measurement * SAMPLES_AVG_INVS;
		current_sensor->Iq_feedback = Iq_measurement * SAMPLES_AVG_INVS;
		ticks = 0;
	}

}
