#ifndef CORRECTOR_CONFIG_H
#define CORRECTOR_CONFIG_H


#include "arm_math.h"

typedef struct {
    __IO float32_t Iq_setpoint;      /* written: TIM2 (500Hz)  | read: TIM1 (20kHz) */
} FOC_CurrentControl_t;

typedef struct {
    __IO float32_t speed_setpoint;   /* written: TIM4 (50Hz)   | read: TIM2 (500Hz) */
} FOC_SpeedControl_t;

typedef struct {
    __IO float32_t position_setpoint; /* written: app layer     | read: TIM4 (50Hz)  */
} FOC_PositionControl_t;


typedef struct {
    arm_pid_instance_f32 PID_speed;
    arm_pid_instance_f32 PID_position;
    arm_pid_instance_f32 PID_current_d;
    arm_pid_instance_f32 PID_current_q;
} PID_HandleTypeDef;



#endif
