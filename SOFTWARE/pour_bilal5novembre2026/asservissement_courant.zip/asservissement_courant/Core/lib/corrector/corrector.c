#include <corrector/corrector.h>


void init_corrector(PID_HandleTypeDef *pid_control){
	pid_control->PID_current_d.Kd = UNUSED_COEFF;
	pid_control->PID_current_d.Kp = KP_CURRENT_D;
	pid_control->PID_current_d.Ki = KP_CURRENT_D * (TS_10kHz / TI_CURRENT_D);
	arm_pid_init_f32(&pid_control->PID_current_d, 1);

	pid_control->PID_current_q.Kd = UNUSED_COEFF;
	pid_control->PID_current_q.Kp = KP_CURRENT_Q;
	pid_control->PID_current_q.Ki = KP_CURRENT_Q * (TS_10kHz / TI_CURRENT_Q);
	arm_pid_init_f32(&pid_control->PID_current_q, 1);

	pid_control->PID_position.Kd  = UNUSED_COEFF;
	pid_control->PID_position.Kp  = KP_POSITION;
	pid_control->PID_position.Ki  = KP_POSITION * (TS_50Hz / TI_POSITION);
	arm_pid_init_f32(&pid_control->PID_position, 1);

	pid_control->PID_speed.Kd     = UNUSED_COEFF;
	pid_control->PID_speed.Kp     = KP_SPEED;
	pid_control->PID_speed.Ki     = KP_SPEED * (TS_500Hz / TI_SPEED);
	arm_pid_init_f32(&pid_control->PID_speed, 1);

}


void position_corrector_sequence(FOC_HandleTypeDef *foc_control) {
//    float32_t pos_ref = foc->position_ctrl.position_setpoint;
//    // ... position PID ...
//    foc->speed_ctrl.speed_setpoint = pid_position_output;
}

void speed_corrector_sequence(FOC_HandleTypeDef *foc_control) {
	FOC_SpeedControl_t   *speed_control   = foc_control->speed_control;
	FOC_CurrentControl_t *current_control = foc_control->current_control;
	PID_HandleTypeDef    *pid_control     = foc_control->pid_control;
	ENC_HandleTypeDef    *encoder_control = foc_control->encoder;

	float32_t spd_ref = speed_control->speed_setpoint;
	float32_t spd_fbk = encoder_control->speed_rads;

	float32_t error_spd = spd_ref - spd_fbk;

	float32_t torque  = CLAMPING(arm_pid_f32(&pid_control->PID_speed, error_spd), MIN_CURRENT, MAX_CURRENT);

	current_control->Iq_setpoint = torque;
}

void current_corrector_sequence(FOC_HandleTypeDef *foc_control) {
	FOC_CurrentControl_t *current_control = foc_control->current_control;
	ANG_HandleTypeDef    *analog_control  = foc_control->analog;
	PID_HandleTypeDef    *pid_control     = foc_control->pid_control;
	MOT_HandleTypeDef    *motor_control   = foc_control->motor;

	float32_t Id_ref = 0.0f;
    float32_t Iq_ref = current_control->Iq_setpoint;

    float32_t Id_fbk = analog_control->Id_feedback;
    float32_t Iq_fbk = analog_control->Iq_feedback;

    float32_t error_d = Id_ref - Id_fbk;
    float32_t error_q = Iq_ref - Iq_fbk;

    float32_t Vd = CLAMPING(arm_pid_f32(&pid_control->PID_current_d, error_d), MIN_VOLTAGE, MAX_VOLTAGE);
    float32_t Vq = CLAMPING(arm_pid_f32(&pid_control->PID_current_q, error_q), MIN_VOLTAGE, MAX_VOLTAGE);

    motor_control->Ud = Vd;
    motor_control->Uq = Vq;
}
