#ifndef CURRENT_CORRECTOR_H
#define CURRENT_CORRECTOR_H

#include <FOC/foc_config.h>


#define KP_CURRENT_Q 0.01f
#define TI_CURRENT_Q 0.01f
#define TD_CURRENT_Q 0.01f

#define KP_CURRENT_D 0.01f
#define TI_CURRENT_D 0.01f
#define TD_CURRENT_D 0.01f

#define KP_SPEED 0.01f
#define TI_SPEED 0.01f
#define TD_SPEED 0.01f

#define KP_POSITION  0.01f
#define TI_POSITION  0.01f
#define TD_POSITION  0.01f

#define UNUSED_COEFF 0.0f

#define MAX_VOLTAGE 12.0f
#define MIN_VOLTAGE 0.0f

#define MAX_CURRENT 12.0f
#define MIN_CURRENT 0.0f

#define MAX_SPEED   104.71975511f  // rad/s
#define MIN_SPEED   -MAX_SPEED

#define MAX_POSITION 1000U // mm
#define MIN_POSITION 0U


#define CLAMPING(val, min, max)  ((val) < (min) ? (min) : ((val) > (max) ? (max) : (val)))




void init_corrector(PID_HandleTypeDef *pid_control);

void position_corrector_sequence(FOC_HandleTypeDef *foc);
void speed_corrector_sequence(FOC_HandleTypeDef *foc);
void current_corrector_sequence(FOC_HandleTypeDef *foc_control);

#endif
